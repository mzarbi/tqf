import Pyro4
import time
uri = "PYRO:memory_storage@localhost:9090"
remote_storage = Pyro4.Proxy(uri)

while True:
    x = remote_storage.queue_size()
    print(x)
    time.sleep(1)