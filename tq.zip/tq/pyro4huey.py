import signal

import Pyro4
import heapq
import threading
import logging
import base64
from tq.serializer import Serializer
from tq.storage import BaseStorage

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('storage')


@Pyro4.expose
class RemoteMemoryStorage(object):
    def __init__(self, debug=True):
        self._c = 0  # Counter to ensure FIFO behavior for queue.
        self._queue = []  # The task queue.
        self._results = {}  # Storage for task results.
        self._schedule = []  # Scheduled tasks.
        self._lock = threading.RLock()  # Thread-safe operations.
        self.debug = debug
        self._task_status = {}
        self._shutdown_requested = threading.Event()  # Signal for shutdown

    def log(self, message, error=False, exc_info=None):
        """Log a message, respecting the debug setting, and handle error logging."""
        if self.debug:
            if error and exc_info:
                logger.error(message, exc_info=exc_info)
            else:
                logger.info(message)

    def tasks_status(self):
        return self._task_status

    def set_task_status(self, task_id, status):
        try:
            with self._lock:
                self._task_status[task_id] = status
                self.log(f"Marked task {task_id} as completed")
        except Exception as e:
            self.log(f"Error marking task {task_id} as completed: {str(e)}", error=True, exc_info=True)

    def get_task_status(self, task_id):
        """Return the status of a task, with error handling."""
        try:
            with self._lock:
                return self._task_status.get(task_id, 'unknown')
        except Exception as e:
            self.log(f"Error getting status for task {task_id}: {str(e)}", error=True, exc_info=True)
            return 'error'

    def enqueue(self, data, priority=None):
        """Enqueue a task with optional priority."""
        with self._lock:
            self._c += 1
            priority = 0 if priority is None else -priority
            heapq.heappush(self._queue, (priority, self._c, data))
            self.log(f"Enqueued task: {data} with priority {priority}")

    def dequeue(self):
        """Dequeue the next task."""
        with self._lock:
            try:
                _, _, data = heapq.heappop(self._queue)
                self.log(f"Dequeued task: {data}")
            except IndexError:
                return None
            else:
                return data

    def queue_size(self):
        """Return the size of the queue."""
        size = len(self._queue)
        self.log(f"Queue size: {size}")
        return size

    def flush_queue(self):
        """Clear all tasks from the queue."""
        with self._lock:
            self._queue = []
            self.log("Flushed the queue")

    def add_to_schedule(self, data, ts):
        """Add a task to the schedule."""
        with self._lock:
            heapq.heappush(self._schedule, (ts, data))
            self.log(f"Added task to schedule: {data} at timestamp {ts}")

    def read_schedule(self, ts):
        """Read and return tasks from the schedule up to a certain time."""
        with self._lock:
            accum = []
            while self._schedule:
                schedule_ts, data = self._schedule[0]  # Peek at the first item
                if schedule_ts <= ts:
                    heapq.heappop(self._schedule)  # Remove the item if it's time
                    accum.append(data)
                    self.log(f"Read scheduled task: {data} for timestamp {ts}")
                else:
                    break
            return accum

    def flush_schedule(self):
        """Clear all tasks from the schedule."""
        with self._lock:
            self._schedule = []
            self.log("Flushed the schedule")

    def put_data(self, key, value):
        """Store a result."""
        with self._lock:
            self._results[key] = value
            self.log(f"Stored result for key: {key}")

    def peek_data(self, key):
        """Return a result without removing it."""
        with self._lock:
            result = self._results.get(key)
            if result is not None:
                self.log(f"Peeked at result for key: {key}")
            else:
                self.log(f"No result found for key: {key}")
            return result

    def pop_data(self, key):
        """Return and remove a result."""
        with self._lock:
            result = self._results.pop(key, None)
            if result is not None:
                self.log(f"Popped result for key: {key}")
            else:
                self.log(f"No result to pop for key: {key}")
            return result

    def has_data_for_key(self, key):
        """Check if a result exists."""
        exists = key in self._results
        self.log(f"Checking if result exists for key: {key}: {'Yes' if exists else 'No'}")
        return exists

    def result_store_size(self):
        """Return the number of stored results."""
        size = len(self._results)
        self.log(f"Result store size: {size}")
        return size

    def flush_results(self):
        """Clear all results."""
        with self._lock:
            self._results = {}
            self.log("Flushed all results")

    def enqueued_items(self, limit=None):
        """Return a list of enqueued items, limited by 'limit' if provided."""
        with self._lock:
            items = [data for _, _, data in sorted(self._queue)]
            if limit is not None:
                items = items[:limit]
            self.log(f"Enqueued items: {items}")
            return items

    def schedule_size(self):
        """Return the number of scheduled tasks."""
        size = len(self._schedule)
        self.log(f"Schedule size: {size}")
        return size

    def scheduled_items(self, limit=None):
        """Return a list of scheduled items, limited by 'limit' if provided."""
        with self._lock:
            items = sorted((ts, data) for ts, data in self._schedule)
            if limit is not None:
                items = items[:limit]
            self.log(f"Scheduled items: {[data for _, data in items]}")
            return [data for _, data in items]

    def result_items(self):
        """Return all result items."""
        with self._lock:
            results = dict(self._results)
            self.log(f"All result items: {results}")
            return results

    def shutdown(self):
        """Perform necessary cleanup before shutdown."""
        logger.info("Initiating cleanup...")
        self._shutdown_requested.set()  # Signal any running thread to stop
        # Here, add any specific shutdown or cleanup logic, like joining threads.
        # If you have background threads, you should join them here.
        logger.info("Cleanup completed.")


class Pyro4MemoryStorage(BaseStorage):
    def __init__(self, name, **storage_kwargs):
        super(Pyro4MemoryStorage, self).__init__(name, **storage_kwargs)
        if 'uri' not in storage_kwargs:
            raise ValueError("A 'uri' must be provided for Pyro4MemoryStorage.")
        uri = storage_kwargs['uri']
        self.remote_storage = Pyro4.Proxy(uri)

    def enqueue(self, data, priority=None):
        self.remote_storage.enqueue(data, priority)

    def dequeue(self):
        data = self.remote_storage.dequeue()
        if isinstance(data, dict) and 'data' in data and 'encoding' in data:
            print(base64.b64decode(data['data']))
            return base64.b64decode(data['data'])

    def read_schedule(self, ts):
        scheduled_items = self.remote_storage.read_schedule(ts)
        return [
            base64.b64decode(item['data']) if isinstance(item, dict) and 'data' in item and 'encoding' in item else item
            for item in scheduled_items]

    def peek_data(self, key):
        data = self.remote_storage.peek_data(key)
        if isinstance(data, dict) and 'data' in data and 'encoding' in data:
            return base64.b64decode(data['data'])

    def pop_data(self, key):
        data = self.remote_storage.pop_data(key)
        if isinstance(data, dict) and 'data' in data and 'encoding' in data:
            return base64.b64decode(data['data'])

    def enqueued_items(self, limit=None):
        items = self.remote_storage.enqueued_items(limit)
        return [
            base64.b64decode(item['data']) if isinstance(item, dict) and 'data' in item and 'encoding' in item else item
            for item in items]

    def result_items(self):
        results = self.remote_storage.result_items()
        decoded_results = {}
        for key, value in results.items():
            if isinstance(value, dict) and 'data' in value and 'encoding' in value:
                decoded_results[key] = base64.b64decode(value['data'])
            else:
                decoded_results[key] = value
        return decoded_results

    def queue_size(self):
        return self.remote_storage.queue_size()

    def flush_queue(self):
        self.remote_storage.flush_queue()

    def add_to_schedule(self, data, ts, utc=False):
        self.remote_storage.add_to_schedule(data, ts)

    def schedule_size(self):
        return self.remote_storage.schedule_size()

    def scheduled_items(self, limit=None):
        return self.remote_storage.scheduled_items(limit)

    def flush_schedule(self):
        self.remote_storage.flush_schedule()

    def put_data(self, key, value, is_result=False):
        self.remote_storage.put_data(key, value)

    def has_data_for_key(self, key):
        return self.remote_storage.has_data_for_key(key)

    def result_store_size(self):
        return self.remote_storage.result_store_size()

    def flush_results(self):
        self.remote_storage.flush_results()

    def set_task_status(self, task_id, status):
        self.remote_storage.set_task_status(task_id, status)


class CustomSerializer(Serializer):
    def _deserialize(self, data):
        if isinstance(data, dict) and 'data' in data and 'encoding' in data:
            raw_bytes = base64.b64decode(data['data'])
            return super()._deserialize(raw_bytes)
        return super()._deserialize(data)


def shutdown(server):
    """Shutdown the server gracefully."""
    logger.info("Shutting down the server...")
    server.shutdown()
    logger.info("Server has been shut down.")


def start_server(host="localhost", port=9090):
    storage = RemoteMemoryStorage()  # Instantiate your storage class

    daemon = Pyro4.Daemon(host=host, port=port)
    uri = daemon.register(storage, objectId="memory_storage")
    logger.info(f"Service started. Object uri = {uri}")

    def signal_handler(signal, frame):
        logger.info('Signal received, shutting down...')
        storage.shutdown()  # Shutdown your storage cleanly
        shutdown(daemon)

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    try:
        daemon.requestLoop()
    finally:
        daemon.close()


if __name__ == "__main__":
    start_server()
