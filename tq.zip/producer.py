from app import add_numbers

for i in range(100):
    add_numbers(2,5)