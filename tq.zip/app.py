import time

# Replace this with the actual URI printed by your Pyro4 service
from tq import Huey
from tq.pyro4huey import Pyro4MemoryStorage, CustomSerializer

uri = "PYRO:memory_storage@localhost:9090"


class CustomHuey(Huey):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def task_with_status_updates(self, *task_args, **task_kwargs):
        def decorator(func):
            # Wrap the original task function
            @self.task(*task_args, **task_kwargs)
            def wrapped_task(*args, **kwargs):
                return func(*args, **kwargs)

            # Define pre and post execute hooks
            @self.pre_execute()
            def pre_task_hook(task):
                self.storage.set_task_status(task.id, 'running')

            @self.post_execute()
            def post_task_hook(task, task_value, exc):
                status = 'failed' if exc else 'completed'
                self.storage.set_task_status(task.id, status)

            return wrapped_task

        return decorator


# Initialize Huey with the custom Pyro4 storage
tq = CustomHuey(storage_class=Pyro4MemoryStorage, name='my_app', uri=uri)


# Example task
@tq.task_with_status_updates()
def add_numbers(a, b):
    time.sleep(1)
    print("###################################")
    return a + b


@tq.task()
def add_numbers2(a, b):
    return a + b
